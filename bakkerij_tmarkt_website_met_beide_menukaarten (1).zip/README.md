# Bakkerij T’Markt — website

Deze versie bevat beide echte menukaartfoto’s die door de klant zijn aangeleverd.

Bestanden:
- index.html
- style.css
- script.js
- menu-bakkerij-tmarkt.jpg
- menu-bakkerij-tmarkt-2.jpg

Open `index.html` lokaal in een browser om de website te bekijken.
