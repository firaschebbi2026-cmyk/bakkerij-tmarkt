# Bakkerij T'Markt — website

Open `index.html` in een browser. De website werkt zonder server.

## Bestanden
- `index.html` — pagina en inhoud
- `style.css` — volledige responsive styling
- `script.js` — mobiel menu, product-modal, formulier en scrollnavigatie

## Belangrijk
Het bestelformulier is een front-end demo: het opent een e-mailconcept via `mailto:`. Voor echte online bestellingen kun je het later koppelen aan een backend, e-maildienst of bestelplatform.

De contactgegevens en Google-rating zijn gebaseerd op de informatie die in de opdracht is aangeleverd.
