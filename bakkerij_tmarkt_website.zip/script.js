const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuToggle?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', open);
});
document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

const modal = document.getElementById('productModal');
const modalTitle = document.getElementById('modalTitle');
const modalOrder = document.getElementById('modalOrder');
document.querySelectorAll('[data-product]').forEach(btn => {
  btn.addEventListener('click', () => {
    modalTitle.textContent = btn.dataset.product;
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
  });
});
document.querySelector('.modal-close')?.addEventListener('click', closeModal);
modal?.addEventListener('click', e => { if (e.target === modal) closeModal(); });
function closeModal() { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); }
modalOrder?.addEventListener('click', closeModal);

const orderForm = document.getElementById('orderForm');
const formMessage = document.getElementById('formMessage');
orderForm?.addEventListener('submit', e => {
  e.preventDefault();
  const data = new FormData(orderForm);
  const text = `Hallo Bakkerij T'Markt,%0A%0ANaam: ${encodeURIComponent(data.get('name'))}%0ATelefoon: ${encodeURIComponent(data.get('phone'))}%0ABestelling: ${encodeURIComponent(data.get('order'))}%0AAfhalen: ${encodeURIComponent(data.get('date'))}`;
  formMessage.innerHTML = `Je aanvraag is voorbereid. <a href="mailto:?subject=Bestelling%20Bakkerij%20T'Markt&body=${text}" style="color:#b66b35;font-weight:700">Open je e-mail om ze te versturen →</a>`;
});

const sections = document.querySelectorAll('main section[id]');
const navLinks = document.querySelectorAll('.nav a:not(.nav-cta)');
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navLinks.forEach(link => link.classList.toggle('active', link.getAttribute('href') === '#' + entry.target.id));
    }
  });
}, {rootMargin:'-35% 0px -55% 0px'});
sections.forEach(s => observer.observe(s));
